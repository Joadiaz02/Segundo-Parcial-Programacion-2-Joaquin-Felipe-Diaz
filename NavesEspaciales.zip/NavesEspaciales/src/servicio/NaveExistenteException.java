
package servicio;

public class NaveExistenteException extends RuntimeException{
    
    public static final String MESSAGE = "Ya existe esa nave";

    public NaveExistenteException() {
        super(MESSAGE); 
    }

}
