
package modelo;


public enum Categoria {
    TRANSPORTE, CIENTIFICA, MILITAR;
}
