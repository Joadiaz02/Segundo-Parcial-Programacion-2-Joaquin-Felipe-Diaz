
package modelo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import servicio.NaveExistenteException;

public class Inventario<T> implements Guardable<T>, Serializable {
    List<T> items = new ArrayList<>();

    @Override
    public void agregar(T item) {
    if (item == null) {
        throw new IllegalArgumentException("No se puede agregar nulos");
    }
    int i = 0;
    while (i < items.size()) {
        if (items.get(i).equals(item)) {
            throw new NaveExistenteException();
        }
        i++;
    }
    items.add(item);
}

    @Override
    public T obtener(int indice) {
        validarIndice(indice);
        return items.get(indice);
    }

    public void validarIndice(int indice){
        if(indice < 0 || indice >= items.size()){
            throw new IndexOutOfBoundsException("Indice fuera de rango");
        }
    }
    
    @Override
    public void eliminar(int indice) {
        validarIndice(indice);
        items.remove(indice);
    }

    @Override
    public int tamanio() {
        return items.size();
    }

    @Override
    public Iterator<T> iterator() {
        if(!items.isEmpty() && items.get(0) instanceof Comparable){
            return iterator((Comparator <? super T>) Comparator.naturalOrder());
        }
        return new ArrayList<>(items).iterator();
    }
    
    public Iterator<T> iterator(Comparator <? super T> comparator){
        List<T> aux = new ArrayList<>(items);
        aux.sort(comparator);
        return aux.iterator();
    }
    
    public void ordenar(Comparator<? super T> comparator) {
        items.sort(comparator);
    }

    public void mostrarContenido(){
        System.out.println("Contenido del inventario: ");
        mostrarContenido((Comparator <? super T>) Comparator.naturalOrder());
    }
    
    public void mostrarContenido(Comparator <? super T> comparator){
        System.out.println("Contenido del inventario: ");
        Iterator<T> it = iterator(comparator);
        while(it.hasNext()){
            System.out.println(it.next());
        }
    }

    @Override
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> toReturn = new ArrayList<>();
        for(T item: items){
            if(criterio.test(item)){
                toReturn.add(item);
            }
        }
        return toReturn;
    }

    
    
    @Override
    public void paraCadaElemento(Consumer<? super T> accion) {
        for(T item : items){
            accion.accept(item);
        }
    }

    @Override
    public List<T> transformar(Function<? super T, ? extends T> transformacion) {
        List<T> toReturn = new ArrayList<>();
        for(T item: items){
            toReturn.add(transformacion.apply(item));
        }
        return toReturn;
    }
    
    public void guardarEnArchivo(String path) {
    try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
        salida.writeObject(items);
    } catch (IOException ex) {
        ex.printStackTrace();
        System.out.println(ex.getMessage());
    }
}
    
    public List<NaveEspacial> cargarDesdeArchivo(String path) {
    List<NaveEspacial> toReturn = null;
    try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
        toReturn = (List<NaveEspacial>) entrada.readObject();
    } catch (IOException | ClassNotFoundException ex) {
        System.out.println(ex.getMessage());
    }
    return toReturn;
    }
    
    
    
    public  void guardarEnCSV( String path) {
        File archivo = new File(path);
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))){
            bw.write("id,tipo,marca,precio\n");
            for(T n: items){
                bw.write(((NaveEspacial) n).toCSV()+"\n");
            }
        } catch (IOException ex) {
        System.out.println(ex.getMessage());
    }
        
    }

    public  List<NaveEspacial> cargarDesdeCSV(String path) {
        List<NaveEspacial> toReturn = new ArrayList<>();
        File archivo = new File(path);
        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            br.readLine();
            while ((linea = br.readLine()) != null) {
                if(linea.endsWith("\n")){
                    linea = linea.substring(linea.length() -1);
                }
                toReturn.add(NaveEspacial.fromCSV(linea));
                }    
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return toReturn;
    }
    
    
}
