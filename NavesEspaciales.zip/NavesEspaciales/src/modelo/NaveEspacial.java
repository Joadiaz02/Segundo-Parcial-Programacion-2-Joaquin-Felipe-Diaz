package modelo;


import java.io.Serializable;
import java.util.Objects;

public class NaveEspacial implements Comparable<NaveEspacial>,CSVSerializable ,Serializable {
    private int id;
    private String nombre;
    private Categoria categoria;
    private int capacidadTripulacion;

    public NaveEspacial(int id,String nombre, int capacidadTripulacion,Categoria categoria) {
        this.id = id;
        this.nombre = nombre;
        this.categoria = categoria;
        this.capacidadTripulacion = capacidadTripulacion;
    }

    public String getNombre() {
        return nombre;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public int getCapacidadTripulacion() {
        return capacidadTripulacion;
    }

    @Override
    public String toString() {
        return "NaveEspacial{" + "nombre=" + nombre + ", categoria=" + categoria + ", capacidadTripulacion=" + capacidadTripulacion + '}';
    }


    @Override
    public boolean equals(Object o){
        if(o==null){
            return false;
        }
        if(o instanceof NaveEspacial n){
           return Integer.compare(id, n.id)==0;
        }
        if(o instanceof Categoria t){
            return categoria.equals(t);
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
    
    @Override
    public String toCSV() {
        return id + "," + nombre + "," + categoria.toString() + "," + capacidadTripulacion;
    }
    
    @Override
    public int compareTo(NaveEspacial n){
        return Integer.compare(id, n.id);
    }
    
    
    
    public static NaveEspacial fromCSV(String naveCSV){
    NaveEspacial toReturn= null;
    String[] values = naveCSV.split(",");
        if(values.length==4){
            int id = Integer.parseInt(values[0]);
            String nombre = values[1];
            int capacidadTripulacion = Integer.parseInt(values[2]);
            Categoria categoria = Categoria.valueOf(values[3].trim().toUpperCase());
            toReturn = new NaveEspacial(id,nombre,capacidadTripulacion,categoria);
    }
        return toReturn;
    }
}
