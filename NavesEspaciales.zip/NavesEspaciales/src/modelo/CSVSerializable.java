
package modelo;

public interface CSVSerializable {
    String toCSV();
}
